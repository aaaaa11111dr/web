<?php
require __DIR__ . '/app/bootstrap.php';
require_install();
$settings = get_settings();
$hasAccess = has_front_access($settings);
$q = trim((string)($_GET['q'] ?? ''));
$page = max(1, min(10, (int)($_GET['page'] ?? 1)));
$data = null; $error = '';
if ($q !== '' && $hasAccess && bool_setting($settings, 'search_enabled')) {
    try { $data = perform_search($q, $settings, $page); } catch (Throwable $e) { $error = $e->getMessage(); }
}
$isResult = ($q !== '');
$pageTitle = render_tdk_template((string)($settings[$isResult ? 'result_title' : 'home_title'] ?? ''), $settings, $q) ?: ($isResult ? $q . ' - ' . $settings['site_name'] : $settings['site_name']);
$pageDescription = render_tdk_template((string)($settings[$isResult ? 'result_description' : 'home_description'] ?? ''), $settings, $q);
$pageKeywords = render_tdk_template((string)($settings[$isResult ? 'result_keywords' : 'home_keywords'] ?? ''), $settings, $q);
?>
<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title><?= e($pageTitle) ?></title><?php if ($pageDescription !== ''): ?><meta name="description" content="<?= e($pageDescription) ?>"><?php endif; ?><?php if ($pageKeywords !== ''): ?><meta name="keywords" content="<?= e($pageKeywords) ?>"><?php endif; ?><link rel="stylesheet" href="/assets/style.css?v=2026051401"></head><body class="<?= $isResult ? 'result-body' : 'home-body' ?>"><div class="shell search-shell">
<?php if ($isResult): ?>
<!-- Result page -->
<header class="result-topbar">
  <a class="result-logo" href="/"><?= brand_text($settings['site_name']) ?></a>
  <form class="result-search-box" method="get" action="/"><input name="q" type="search" value="<?= e($q) ?>" maxlength="160" autofocus><button type="submit" aria-label="搜索"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg></button></form>
  <nav class="result-nav"></nav>
</header>
<main class="result-layout"><section class="result-main"><?php if ($error): ?><div class="state error"><?= e($error) ?></div><?php endif; ?>
<?php if ($data): ?>
  <?php if (!empty($data['blocked'])): ?>
    <div class="blocked-page"><div class="blocked-icon">⛔</div><h2>搜索被拦截</h2><p class="blocked-msg"><?= e($data['blocked_word']) ?>词为非法关键词，请合规使用</p><?= render_ad_pool('blocked', '拦截页广告') ?></div>
  <?php elseif (!empty($data['resource_exhausted'])): ?>
    <div class="blocked-page"><div class="blocked-icon">🕐</div><h2>资源繁忙</h2><p class="blocked-msg"><?= e($data['message'] ?? '因资源耗尽，请稍等再访问') ?></p><?= render_ad_pool('resource', '资源耗尽页广告') ?></div>
  <?php else: ?>
    <p class="result-count">约 <?= count($data['results']) ?> 条结果</p>
    <?= render_ad_pool('results_top', '结果顶部广告') ?>
    <div class="results"><?php foreach ($data['results'] as $i => $r): ?>
      <?php if ($i === (int)(count($data['results']) / 2)): ?><?= render_ad_pool('results_middle', '结果中部广告') ?><?php endif; ?>
      <article class="result-card"><a class="result-title" href="<?= e($r['open_url']) ?>" target="_blank" rel="noopener noreferrer"><?= e($r['title']) ?></a><div class="result-url"><?= e(parse_url((string)$r['url'], PHP_URL_HOST) ?: $r['display_url']) ?></div><p><?= e($r['snippet']) ?></p></article>
    <?php endforeach; ?></div>
    <?= render_ad_pool('results_bottom', '结果底部广告') ?>
    <nav class="pager" id="pager" data-countdown="<?= $cd = int_setting($settings, 'pager_countdown_seconds', 0, 300, 20) ?>"><?php
    $maxPage = 10;
    $perPage = 8;
    $start = max(1, min($data['page'] - (int)($perPage / 2), $maxPage - $perPage + 1));
    $end = min($maxPage, $start + $perPage - 1);
    if ($data['page'] > 1): ?><a class="button secondary pager-link" href="/?q=<?= urlencode($q) ?>&page=<?= $data['page'] - 1 ?>">‹</a><?php endif;
    for ($p = $start; $p <= $end; $p++):
      if ($p === $data['page']): ?><span class="page-current"><?= $p ?></span><?php else: ?><a class="button secondary pager-link" href="/?q=<?= urlencode($q) ?>&page=<?= $p ?>"><?= $p ?></a><?php endif;
    endfor;
    if ($data['page'] < $maxPage): ?><a class="button secondary pager-link" href="/?q=<?= urlencode($q) ?>&page=<?= $data['page'] + 1 ?>">›</a><?php endif; ?></nav>
    <?php if ($cd > 0): ?><p class="pager-cd-bar" id="pagerCdBar"><strong id="pagerCdNum"><?= $cd ?></strong> 秒后可以翻页</p><?php endif; ?>
  <?php endif; ?>
<?php elseif ($q !== ''): ?><p class="state muted">没有解析到结果，可能需要调整代理或稍后再试。</p><?php endif; ?>
</section><?php if ($data && empty($data['blocked']) && empty($data['resource_exhausted'])): ?><?php $sideAd = render_ad_pool('results_side', '结果右侧广告'); if ($sideAd !== ''): ?><aside class="result-side"><div class="side-ad-card"><div class="side-ad-title">推荐</div><?= $sideAd ?></div></aside><?php endif; ?><?php endif; ?></main>
<?php else: ?>
<!-- Home page -->
<header class="topbar"><div class="brand"><?= brand_text($settings['site_name']) ?></div><nav></nav></header>
<?php if (!$hasAccess): ?><main class="center-card auth-card"><div class="mark"><?= brand_text($settings['site_name']) ?></div><h1>访问受限</h1><p>当前 IP 不在白名单内，请联系管理员处理。</p></main>
<?php else: ?><main class="search-main"><section class="hero"><div class="wordmark"><?= brand_text($settings['site_name']) ?></div><p><?= e($settings['site_notice']) ?></p><form class="search-box" method="get" action="/"><input name="q" type="search" placeholder="输入关键词搜索" maxlength="160" autofocus><button type="submit" aria-label="搜索"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg></button></form><?= render_ad_pool('home', '首页广告') ?></section></main><footer class="site-footer"><?= e($settings['footer_notice']) ?></footer><?php endif; ?>
<?php endif; ?>
</div><script>
(function(){
  var pager = document.getElementById('pager');
  if(!pager) return;
  var cd = parseInt(pager.dataset.countdown) || 0;
  if(cd <= 0) return;
  var links = pager.querySelectorAll('.pager-link');
  var cdNum = document.getElementById('pagerCdNum');
  var cdBar = document.getElementById('pagerCdBar');
  links.forEach(function(a){ a.classList.add('disabled'); });
  pager.addEventListener('click', function(e){
    if(e.target.classList.contains('disabled') || e.target.closest('.disabled')){
      e.preventDefault(); e.stopPropagation();
    }
  }, true);
  var t = setInterval(function(){
    cd--;
    if(cdNum) cdNum.textContent = cd;
    if(cd <= 0){
      clearInterval(t);
      if(cdBar) cdBar.innerHTML = '可点击翻页';
      links.forEach(function(a){ a.classList.remove('disabled'); });
    }
  },1000);
})();
</script></body></html>
